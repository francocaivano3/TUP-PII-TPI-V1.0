def menu():
    return "Bienvenidos/as.\n1- Iniciar juego.\n2- Mostrar puntuaciones\n3- Finalizar"

def nuevoJuego():
    